package com.kevin.moneyboard;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.animation.DecelerateInterpolator;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ_BACKUP = 201;
    private static final int REQ_RESTORE = 202;
    private static final int REQ_CSV = 203;

    private FinanceDb db;
    private SharedPreferences prefs;
    private LinearLayout pageHost;
    private TextView[] navItems;
    private int selectedNav = 0;
    private Calendar addDate = Calendar.getInstance();
    private Calendar customStart = null;
    private Calendar customEnd = null;

    private int BG, CARD, CARD_ALT, TEXT, MUTED, LINE, BLUE, BLUE_SOFT, GREEN, GREEN_SOFT,
            RED, RED_SOFT, ORANGE, ORANGE_SOFT, PURPLE, PURPLE_SOFT, NAV_BG, SHADOW, INPUT_BG;
    private boolean dark;

    private final DecimalFormat money = new DecimalFormat("#,##0.00");
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.CHINA);
    private final SimpleDateFormat dayFmt = new SimpleDateFormat("MM月dd日", Locale.CHINA);
    private final SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm", Locale.CHINA);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new FinanceDb(this);
        prefs = getSharedPreferences("moneyboard_settings", MODE_PRIVATE);
        applyPalette();
        applySystemBars();
        setContentView(buildRoot());
        showHome();
    }

    private void applyPalette() {
        String mode = prefs == null ? "light" : prefs.getString("theme", "light");
        if ("system".equals(mode)) {
            dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        } else dark = "dark".equals(mode);

        if (dark) {
            BG = Color.rgb(14, 20, 27);
            CARD = Color.rgb(24, 32, 42);
            CARD_ALT = Color.rgb(29, 39, 50);
            TEXT = Color.rgb(244, 247, 251);
            MUTED = Color.rgb(155, 166, 180);
            LINE = Color.rgb(48, 60, 74);
            NAV_BG = Color.rgb(17, 24, 32);
            INPUT_BG = Color.rgb(31, 41, 53);
        } else {
            BG = Color.rgb(248, 250, 253);
            CARD = Color.WHITE;
            CARD_ALT = Color.rgb(251, 252, 254);
            TEXT = Color.rgb(17, 24, 39);
            MUTED = Color.rgb(112, 122, 139);
            LINE = Color.rgb(231, 235, 241);
            NAV_BG = Color.WHITE;
            INPUT_BG = Color.rgb(246, 248, 251);
        }
        BLUE = Color.rgb(58, 132, 247);
        BLUE_SOFT = dark ? Color.rgb(25, 52, 79) : Color.rgb(234, 244, 255);
        GREEN = Color.rgb(18, 181, 121);
        GREEN_SOFT = dark ? Color.rgb(22, 74, 57) : Color.rgb(229, 250, 241);
        RED = Color.rgb(255, 73, 91);
        RED_SOFT = dark ? Color.rgb(82, 38, 46) : Color.rgb(255, 237, 240);
        ORANGE = Color.rgb(245, 154, 35);
        ORANGE_SOFT = dark ? Color.rgb(78, 56, 28) : Color.rgb(255, 246, 230);
        PURPLE = Color.rgb(128, 92, 246);
        PURPLE_SOFT = dark ? Color.rgb(56, 44, 92) : Color.rgb(243, 238, 255);
        SHADOW = dark ? Color.TRANSPARENT : Color.argb(18, 15, 23, 42);
    }

    private void applySystemBars() {
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(NAV_BG);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    private View buildRoot() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        GlassBackdropView backdrop = new GlassBackdropView();
        root.addView(backdrop, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(Color.TRANSPARENT);
        root.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        pageHost = new LinearLayout(this);
        pageHost.setOrientation(LinearLayout.VERTICAL);
        pageHost.setBackgroundColor(Color.TRANSPARENT);
        content.addView(pageHost, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.setPadding(dp(8), dp(6), dp(8), dp(8));
        nav.setBackground(glassDrawable(0));
        nav.setElevation(dp(12));

        String[] labels = {"⌂\n首页", "✎\n记账", "▥\n分析", "⚙\n我的"};
        Runnable[] pages = {this::showHome, this::showAdd, this::showAnalysis, this::showSettings};
        navItems = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            TextView item = text(labels[i], 11, false, MUTED);
            item.setGravity(Gravity.CENTER);
            item.setLineSpacing(0, .92f);
            item.setOnClickListener(v -> {
                selectedNav = index;
                updateNav();
                pages[index].run();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1f);
            nav.addView(item, lp);
            navItems[i] = item;
        }
        content.addView(nav);
        updateNav();
        return root;
    }

    private void updateNav() {
        if (navItems == null) return;
        for (int i = 0; i < navItems.length; i++) {
            boolean on = i == selectedNav;
            navItems[i].setTextColor(on ? (i == 0 ? GREEN : BLUE) : MUTED);
            navItems[i].setTypeface(Typeface.DEFAULT, on ? Typeface.BOLD : Typeface.NORMAL);
        }
    }

    private void showHome() {
        selectNav(0);
        Calendar now = Calendar.getInstance();
        long[] cycle = cycleRange(now);
        FinanceDb.Summary s = db.getSummary(cycle[0], cycle[1]);
        FinanceDb.Plan plan = getPlanForCycle(now);

        LinearLayout body = pageBody();
        body.addView(v14BrandHeader());
        body.addView(v12CycleHeadline(now));
        body.addView(v12HeroBudgetCard(now, s, plan), cardParams(0));
        body.addView(v12CompactMetrics(s), cardParams(10));
        body.addView(v12ChartCard("每日消费趋势", "长按或拖动查看每日金额", new LineChartView(dailySeries(cycle[0], cycle[1]), BLUE, cycle[0], cycle[1]), this::showExpenseDetails), cardParams(10));
        body.addView(v12CategoryCard(now), cardParams(10));
        body.addView(goalCard(s, plan), cardParams(10));
        body.addView(recentCard(), cardParams(10));
        mount(body);
    }

    private View v14BrandHeader() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Moeny Board", 27, true, TEXT);
        box.addView(title);
        TextView sub = text(cycleModeLabel() + " · 点预算卡设置额度 · 长按趋势图看金额", 12, false, MUTED);
        sub.setPadding(0, dp(5), 0, dp(15));
        box.addView(sub);
        return box;
    }

    private View v12CycleHeadline(Calendar now) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("本周期", 23, true, TEXT);
        TextView pill = text(compactCycle(now), 12, true, BLUE);
        pill.setGravity(Gravity.CENTER);
        pill.setPadding(dp(11), dp(6), dp(11), dp(6));
        pill.setBackground(glassTintDrawable(BLUE_SOFT, 14));
        pill.setOnClickListener(v -> showCycleSettings());
        row.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(pill);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(2), dp(2), dp(2), dp(9));
        row.setLayoutParams(lp);
        return row;
    }

    private View v12HeroBudgetCard(Calendar now, FinanceDb.Summary s, FinanceDb.Plan p) {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        hero.setBackground(glassHeroDrawable(24));
        hero.setElevation(dp(5));

        int soft = Color.rgb(220, 224, 255);
        hero.addView(text("本周期可用预算", 13, true, soft));
        double remaining = p.budget - s.expense;
        String big = p.budget > 0 ? (remaining >= 0 ? "¥" + money.format(remaining) : "-¥" + money.format(-remaining)) : "未设置额度";
        TextView amount = text(big, p.budget > 0 ? 31 : 23, true, Color.WHITE);
        amount.setPadding(0, dp(7), 0, dp(14));
        hero.addView(amount);

        LinearLayout lower = new LinearLayout(this);
        lower.setOrientation(LinearLayout.HORIZONTAL);
        lower.setGravity(Gravity.CENTER_VERTICAL);
        double rate = p.budget > 0 ? s.expense / p.budget : 0;
        RingProgressView ring = new RingProgressView(rate, Color.rgb(126, 114, 255), Color.argb(80, 255, 255, 255), Color.WHITE);
        lower.addView(ring, new LinearLayout.LayoutParams(dp(104), dp(104)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(18), 0, 0, 0);
        info.addView(v14HeroStat("预算已用", "¥" + money.format(s.expense), soft));
        info.addView(v14HeroStat("预算上限", p.budget > 0 ? "¥" + money.format(p.budget) : "待设置", soft));
        info.addView(v14HeroStat("周期", compactCycle(now), soft));
        lower.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        hero.addView(lower);
        hero.setOnClickListener(v -> editTotalPlan(now, this::showHome));
        return hero;
    }

    private View v14HeroStat(String label, String value, int soft) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView l = text(label, 12, false, soft);
        TextView v = text(value, 13, true, Color.WHITE);
        v.setGravity(Gravity.END);
        row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(v);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(4));
        row.setLayoutParams(lp);
        return row;
    }

    private View v12CompactMetrics(FinanceDb.Summary s) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.HORIZONTAL);
        outer.setPadding(0, dp(2), 0, dp(2));
        outer.addView(v12MetricPill("收入", s.income, GREEN, GREEN_SOFT, null), weightMargin(3));
        outer.addView(v12MetricPill("消费", s.expense, RED, RED_SOFT, null), weightMargin(3));
        outer.addView(v12MetricPill("负债", s.debt, ORANGE, ORANGE_SOFT, null), weightMargin(3));
        outer.addView(v12MetricPill("结余", s.net(), BLUE, BLUE_SOFT, null), weightMargin(3));
        return outer;
    }

    private View v12MetricPill(String label, double value, int accent, int soft, Runnable action) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(7), dp(12), dp(7), dp(12));
        box.setBackground(glassTintDrawable(soft, 18));
        box.addView(text(label, 11, true, accent));
        TextView v = text(shortMoney(value), 13, true, TEXT);
        v.setPadding(0, dp(4), 0, 0);
        box.addView(v);
        if (action != null) box.setOnClickListener(x -> action.run());
        return box;
    }

    private View v12ChartCard(String title, String subtitle, View chart, Runnable detailsAction) {
        LinearLayout c = card();
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.addView(text(title, 17, true, TEXT));
        TextView sub = text(subtitle, 12, false, MUTED);
        sub.setPadding(0, dp(4), 0, 0);
        copy.addView(sub);
        head.addView(copy, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView details = text("查看明细  ›", 11, true, BLUE);
        details.setGravity(Gravity.CENTER);
        details.setPadding(dp(10), dp(7), dp(10), dp(7));
        details.setBackground(ripple(BLUE_SOFT, 0, 14));
        details.setOnClickListener(v -> detailsAction.run());
        head.addView(details);
        c.addView(head);
        LinearLayout.LayoutParams chartLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220));
        chartLp.setMargins(0, dp(8), 0, 0);
        c.addView(chart, chartLp);
        return c;
    }

    private View v12CategoryCard(Calendar now) {
        long[] r = cycleRange(now);
        Map<String, Double> map = db.getPurposeTotals(FinanceDb.TYPE_EXPENSE, r[0], r[1]);
        FinanceDb.Summary s = db.getSummary(r[0], r[1]);
        LinearLayout c = card();
        c.addView(text("消费分类占比", 17, true, TEXT));
        TextView sub = text("看看钱主要花在哪些地方 · 点击查看每笔明细", 12, false, MUTED);
        sub.setPadding(0, dp(4), 0, dp(12));
        c.addView(sub);

        List<String> labels = new ArrayList<>();
        List<Double> values = new ArrayList<>();
        int take = 0;
        for (Map.Entry<String, Double> e : map.entrySet()) {
            if (take++ >= 5) break;
            labels.add(e.getKey());
            values.add(e.getValue());
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        DonutChartView donut = new DonutChartView(values, s.expense);
        row.addView(donut, new LinearLayout.LayoutParams(dp(128), dp(128)));
        LinearLayout legend = new LinearLayout(this);
        legend.setOrientation(LinearLayout.VERTICAL);
        legend.setPadding(dp(12), 0, 0, 0);
        if (labels.isEmpty()) legend.addView(text("暂无消费记录", 13, false, MUTED));
        else {
            double total = 0; for (double v : values) total += v;
            int[] colors = chartColors();
            for (int i = 0; i < labels.size(); i++) legend.addView(legendRow(labels.get(i), values.get(i), total, colors[i % colors.length]));
        }
        row.addView(legend, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        c.addView(row);
        return c;
    }

    private void showExpenseDetails() {
        Calendar now = Calendar.getInstance();
        long[] range = cycleRange(now);
        FinanceDb.Summary s = db.getSummary(range[0], range[1]);
        Map<String, Double> totals = db.getPurposeTotals(FinanceDb.TYPE_EXPENSE, range[0], range[1]);
        List<FinanceDb.Record> rows = db.getRecords(FinanceDb.TYPE_EXPENSE, range[0], range[1], 500);

        LinearLayout body = pageBody();
        body.addView(backTopBar("消费明细", this::showHome));

        LinearLayout summary = card();
        summary.addView(text("本周期消费", 12, true, MUTED));
        TextView total = text("¥" + money.format(s.expense), 30, true, RED);
        total.setPadding(0, dp(5), 0, dp(4));
        summary.addView(total);
        summary.addView(text(displayCycle(now) + "  ·  " + rows.size() + " 笔", 11, false, MUTED));
        body.addView(summary, cardParams(0));

        body.addView(sectionLabel("钱花在哪里", null));
        if (totals.isEmpty()) {
            LinearLayout empty = card();
            TextView t = text("本周期还没有消费记录", 13, false, MUTED);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(20), 0, dp(20));
            empty.addView(t);
            body.addView(empty, cardParams(0));
        } else {
            double max = 0; for (double v : totals.values()) max = Math.max(max, v);
            for (Map.Entry<String, Double> e : totals.entrySet()) {
                String purpose = e.getKey();
                double value = e.getValue();
                LinearLayout c = card();
                c.setPadding(dp(14), dp(12), dp(14), dp(12));
                LinearLayout line = new LinearLayout(this);
                line.setOrientation(LinearLayout.HORIZONTAL);
                line.setGravity(Gravity.CENTER_VERTICAL);
                line.addView(categoryIcon(purpose, 38), new LinearLayout.LayoutParams(dp(38), dp(38)));
                LinearLayout info = new LinearLayout(this);
                info.setOrientation(LinearLayout.VERTICAL);
                info.setPadding(dp(10), 0, 0, 0);
                info.addView(text(purpose, 13, true, TEXT));
                int count = countExpensePurpose(rows, purpose);
                info.addView(text(count + " 笔 · 点击查看具体消费", 10, false, MUTED));
                line.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                line.addView(text("¥" + money.format(value), 13, true, RED));
                c.addView(line);
                c.addView(progressLine(max <= 0 ? 0 : value / max, RED), progressParams());
                c.setOnClickListener(v -> showExpenseCategory(purpose));
                body.addView(c, cardParams(7));
            }
        }

        body.addView(sectionLabel("具体怎么花的", null));
        if (rows.isEmpty()) {
            LinearLayout empty = card();
            TextView t = text("暂无明细", 13, false, MUTED);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(18), 0, dp(18));
            empty.addView(t);
            body.addView(empty, cardParams(0));
        } else {
            for (FinanceDb.Record r : rows) body.addView(expenseDetailRow(r), cardParams(7));
        }
        mount(body);
    }

    private int countExpensePurpose(List<FinanceDb.Record> rows, String purpose) {
        int count = 0;
        for (FinanceDb.Record r : rows) if (purpose.equals(r.purpose)) count++;
        return count;
    }

    private void showExpenseCategory(String purpose) {
        long[] range = cycleRange(Calendar.getInstance());
        List<FinanceDb.Record> all = db.getRecords(FinanceDb.TYPE_EXPENSE, range[0], range[1], 500);
        LinearLayout body = pageBody();
        body.addView(backTopBar(purpose + " · 消费明细", this::showExpenseDetails));
        double total = 0; int count = 0;
        for (FinanceDb.Record r : all) if (purpose.equals(r.purpose)) { total += r.amount; count++; }
        LinearLayout top = card();
        top.addView(text(purpose, 13, true, MUTED));
        TextView amount = text("¥" + money.format(total), 28, true, RED);
        amount.setPadding(0, dp(5), 0, dp(3));
        top.addView(amount);
        top.addView(text(count + " 笔消费 · " + displayCycle(Calendar.getInstance()), 11, false, MUTED));
        body.addView(top, cardParams(0));
        for (FinanceDb.Record r : all) if (purpose.equals(r.purpose)) body.addView(expenseDetailRow(r), cardParams(7));
        mount(body);
    }

    private View expenseDetailRow(FinanceDb.Record r) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(11), dp(14), dp(11));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(categoryIcon(r.purpose, 40), new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(10), 0, 0, 0);
        info.addView(text(r.purpose, 13, true, TEXT));
        String detail = dayFmt.format(new Date(r.occurredAt)) + "  " + timeFmt.format(new Date(r.occurredAt));
        if (r.note != null && !r.note.trim().isEmpty()) detail += "  ·  " + r.note.trim();
        info.addView(text(detail, 10, false, MUTED));
        row.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(text("-¥" + money.format(r.amount), 14, true, RED));
        c.addView(row);
        c.setOnLongClickListener(v -> {
            new AlertDialog.Builder(this).setTitle("删除这笔消费？")
                    .setMessage(r.purpose + "  ¥" + money.format(r.amount))
                    .setNegativeButton("取消", null)
                    .setPositiveButton("删除", (d, w) -> { db.deleteRecord(r.id); showExpenseDetails(); })
                    .show();
            return true;
        });
        return c;
    }

    private View homeTopBar() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("▥", 18, true, Color.WHITE);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(gradientRounded(Color.rgb(62, 126, 244), Color.rgb(63, 161, 240), 9));
        row.addView(logo, new LinearLayout.LayoutParams(dp(32), dp(32)));
        TextView title = text("Moeny Board", 20, true, TEXT);
        title.setPadding(dp(9), 0, 0, 0);
        row.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView gear = text("⚙", 21, false, TEXT);
        gear.setGravity(Gravity.CENTER);
        gear.setOnClickListener(v -> showSettings());
        row.addView(gear, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(2), 0, dp(2), dp(12));
        row.setLayoutParams(lp);
        return row;
    }

    private View homeBudgetCard(FinanceDb.Summary s, FinanceDb.Plan p) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(17), dp(18), dp(16));
        c.setBackground(gradientRounded(dark ? Color.rgb(18, 75, 58) : Color.rgb(222, 250, 239), dark ? Color.rgb(14, 88, 66) : Color.rgb(235, 255, 247), 20));
        c.setElevation(dp(2));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text("本期剩余", 12, true, dark ? Color.rgb(148, 224, 193) : Color.rgb(56, 113, 88)));
        double remain = p.budget - s.expense;
        String amount = p.budget <= 0 ? "未设置预算" : (remain >= 0 ? "¥" + money.format(remain) : "-¥" + money.format(-remain));
        TextView big = text(amount, p.budget > 0 ? 29 : 20, true, TEXT);
        big.setPadding(0, dp(4), 0, 0);
        left.addView(big);
        top.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        double rate = p.budget > 0 ? s.expense / p.budget : 0;
        RingProgressView ring = new RingProgressView(rate, GREEN, dark ? Color.rgb(48, 96, 76) : Color.rgb(187, 235, 216), TEXT);
        top.addView(ring, new LinearLayout.LayoutParams(dp(82), dp(82)));
        c.addView(top);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setPadding(0, dp(11), 0, 0);
        bottom.addView(homeBudgetStat("本期已用", "¥" + money.format(s.expense)), weight());
        bottom.addView(homeBudgetStat("本期预算", p.budget > 0 ? "¥" + money.format(p.budget) : "待设置"), weight());
        c.addView(bottom);
        return c;
    }

    private View homeBudgetStat(String label, String value) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(text(label, 11, false, dark ? Color.rgb(151, 188, 173) : Color.rgb(86, 125, 108)));
        TextView v = text(value, 13, true, TEXT);
        v.setPadding(0, dp(3), 0, 0);
        box.addView(v);
        return box;
    }

    private View periodCard(Calendar now) {
        LinearLayout c = rowCard(BLUE_SOFT);
        TextView icon = iconBubble("▣", BLUE, dark ? Color.rgb(34, 65, 95) : Color.WHITE);
        c.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(11), 0, 0, 0);
        info.addView(text("当前周期", 11, true, BLUE));
        info.addView(text(displayCycle(now), 13, true, TEXT));
        c.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView days = text("剩余 " + daysRemaining(now) + " 天", 11, true, MUTED);
        c.addView(days);
        return c;
    }

    private View todaySummary() {
        Calendar start = Calendar.getInstance();
        zeroTime(start);
        Calendar end = (Calendar) start.clone();
        end.add(Calendar.DAY_OF_MONTH, 1);
        FinanceDb.Summary s = db.getSummary(start.getTimeInMillis(), end.getTimeInMillis());
        int count = db.getRecords(null, start.getTimeInMillis(), end.getTimeInMillis(), 200).size();
        LinearLayout c = card();
        c.setPadding(dp(15), dp(14), dp(15), dp(14));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text("今日记录", 13, true, TEXT));
        TextView v = text("¥" + money.format(s.expense), 19, true, s.expense > 0 ? RED : TEXT);
        v.setPadding(0, dp(3), 0, 0);
        left.addView(v);
        row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(text(count + " 笔消费", 12, false, MUTED));
        c.addView(row);
        return c;
    }

    private View quickActions() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(actionButton("✎  记一笔", BLUE, dark ? Color.rgb(27, 60, 103) : Color.rgb(233, 244, 255), this::showAdd), weightMargin(3));
        r1.addView(actionButton("▣  设置预算", GREEN, GREEN_SOFT, this::showBudget), weightMargin(3));
        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.setPadding(0, dp(8), 0, 0);
        r2.addView(actionButton("☷  账单列表", TEXT, CARD, this::showRecords), weightMargin(3));
        r2.addView(actionButton("▥  图表分析", GREEN, GREEN_SOFT, this::showAnalysis), weightMargin(3));
        outer.addView(r1);
        outer.addView(r2);
        return outer;
    }

    private TextView actionButton(String label, int color, int fill, Runnable action) {
        TextView b = text(label, 13, true, color);
        b.setGravity(Gravity.CENTER);
        b.setBackground(ripple(fill, fill == CARD ? LINE : 0, 15));
        b.setOnClickListener(v -> action.run());
        b.setElevation(dark ? 0 : dp(1));
        b.setMinHeight(dp(48));
        return b;
    }

    private View homeMiniMetrics(FinanceDb.Summary s) {
        LinearLayout c = card();
        c.setPadding(dp(10), dp(13), dp(10), dp(13));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(metricMini("收入", s.income, GREEN), weight());
        row.addView(metricMini("消费", s.expense, RED), weight());
        row.addView(metricMini("负债", s.debt, ORANGE), weight());
        row.addView(metricMini("结余", s.net(), BLUE), weight());
        c.addView(row);
        return c;
    }

    private View metricMini(String label, double value, int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.addView(text(label, 11, false, MUTED));
        TextView v = text(shortMoney(value), 13, true, color);
        v.setPadding(0, dp(4), 0, 0);
        box.addView(v);
        return box;
    }

    private View goalCard(FinanceDb.Summary s, FinanceDb.Plan p) {
        LinearLayout c = card();
        LinearLayout head = new LinearLayout(this); head.setOrientation(LinearLayout.HORIZONTAL); head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(text("本期结余目标", 13, true, TEXT), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        double rate = p.target > 0 ? s.net() / p.target : 0;
        head.addView(text(p.target > 0 ? new DecimalFormat("0%").format(Math.max(0, Math.min(1, rate))) : "未设置", 12, true, GREEN));
        c.addView(head);
        c.addView(progressLine(rate, GREEN), progressParams());
        TextView foot = text(p.target > 0 ? "当前净结余 ¥" + money.format(s.net()) + " / 目标 ¥" + money.format(p.target) : "在预算管理里设置本周期净结余目标", 11, false, MUTED);
        foot.setPadding(0, dp(8), 0, 0); c.addView(foot);
        c.setOnClickListener(v -> showBudget());
        return c;
    }

    private View recentCard() {
        LinearLayout c = card();
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(text("最近记录", 15, true, TEXT), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView more = text("查看全部  ›", 12, true, BLUE);
        more.setOnClickListener(v -> showRecords());
        head.addView(more);
        c.addView(head);
        List<FinanceDb.Record> rows = db.getRecent(null, 4);
        if (rows.isEmpty()) {
            TextView empty = text("还没有记录，点“记一笔”开始吧", 13, false, MUTED);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(20), 0, dp(8));
            c.addView(empty);
        } else {
            for (FinanceDb.Record r : rows) c.addView(transactionCompactRow(r));
        }
        return c;
    }

    private View transactionCompactRow(FinanceDb.Record r) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(11), 0, dp(8));
        TextView icon = categoryIcon(r.purpose, 34);
        row.addView(icon, new LinearLayout.LayoutParams(dp(34), dp(34)));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(10), 0, 0, 0);
        info.addView(text(r.purpose, 13, true, TEXT));
        info.addView(text(dayFmt.format(new Date(r.occurredAt)) + "  " + timeFmt.format(new Date(r.occurredAt)), 10, false, MUTED));
        row.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        int color = typeColor(r.type);
        String sign = FinanceDb.TYPE_INCOME.equals(r.type) ? "+" : "-";
        row.addView(text(sign + "¥" + money.format(r.amount), 13, true, color));
        return row;
    }

    private void showAdd() {
        selectNav(1);
        LinearLayout body = pageBody();
        body.addView(simpleTopBar("记一笔", null));
        final int[] selectedType = {0};
        body.addView(typeSegmented(selectedType));

        EditText amount = edit("0.00");
        amount.setTextSize(32);
        amount.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        amount.setGravity(Gravity.CENTER_VERTICAL);
        amount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        amount.setPadding(dp(8), 0, dp(8), 0);
        amount.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout amountWrap = card();
        amountWrap.setPadding(dp(16), dp(10), dp(16), dp(10));
        TextView yuan = text("¥", 22, true, TEXT);
        LinearLayout amountRow = new LinearLayout(this);
        amountRow.setOrientation(LinearLayout.HORIZONTAL);
        amountRow.setGravity(Gravity.CENTER_VERTICAL);
        amountRow.addView(yuan);
        amountRow.addView(amount, new LinearLayout.LayoutParams(0, dp(62), 1f));
        amountWrap.addView(amountRow);
        body.addView(amountWrap, cardParams(12));

        TextView catTitle = text("选择用途", 13, true, TEXT);
        catTitle.setPadding(dp(2), dp(2), 0, dp(8));
        body.addView(catTitle);
        EditText purpose = edit("自定义用途名称");
        body.addView(categoryGrid(purpose));
        LinearLayout.LayoutParams purposeLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        purposeLp.setMargins(0, dp(10), 0, 0);
        body.addView(purpose, purposeLp);

        TextView date = settingField("日期", dateFmt.format(addDate.getTime()));
        date.setOnClickListener(v -> new DatePickerDialog(this, (view, y, m, d) -> {
            addDate.set(y, m, d);
            ((TextView) v).setText("日期                                      " + dateFmt.format(addDate.getTime()));
        }, addDate.get(Calendar.YEAR), addDate.get(Calendar.MONTH), addDate.get(Calendar.DAY_OF_MONTH)).show());
        body.addView(date, fieldParams());

        EditText note = edit("备注（可选）");
        body.addView(note, fieldParams());

        TextView save = filledButton("保存", RED);
        save.setOnClickListener(v -> {
            String p = purpose.getText().toString().trim();
            if (p.isEmpty()) { toast("请选择或填写用途"); return; }
            double val;
            try { val = Double.parseDouble(amount.getText().toString().trim()); }
            catch (Exception e) { toast("请输入正确金额"); return; }
            if (val <= 0) { toast("金额需要大于 0"); return; }
            String type = selectedType[0] == 0 ? FinanceDb.TYPE_EXPENSE : selectedType[0] == 1 ? FinanceDb.TYPE_INCOME : FinanceDb.TYPE_DEBT;
            Calendar t = (Calendar) addDate.clone();
            Calendar now = Calendar.getInstance();
            t.set(Calendar.HOUR_OF_DAY, now.get(Calendar.HOUR_OF_DAY));
            t.set(Calendar.MINUTE, now.get(Calendar.MINUTE));
            t.set(Calendar.SECOND, now.get(Calendar.SECOND));
            db.addRecord(type, p, val, note.getText().toString(), t.getTimeInMillis());
            toast("已保存");
            amount.setText(""); purpose.setText(""); note.setText("");
            showHome();
        });
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        saveLp.setMargins(0, dp(18), 0, dp(16));
        body.addView(save, saveLp);
        mount(body);
    }

    private View typeSegmented(int[] selected) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.setPadding(dp(4), dp(4), dp(4), dp(4));
        wrap.setBackground(rounded(INPUT_BG, 0, 18));
        String[] labels = {"支出", "收入", "负债"};
        int[] colors = {RED, GREEN, ORANGE};
        TextView[] items = new TextView[3];
        Runnable repaint = () -> {
            for (int i = 0; i < 3; i++) {
                boolean on = selected[0] == i;
                items[i].setTextColor(on ? Color.WHITE : MUTED);
                items[i].setTypeface(Typeface.DEFAULT, on ? Typeface.BOLD : Typeface.NORMAL);
                items[i].setBackground(on ? rounded(colors[i], 0, 15) : rounded(Color.TRANSPARENT, 0, 15));
            }
        };
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView item = text(labels[i], 13, false, MUTED);
            item.setGravity(Gravity.CENTER);
            item.setOnClickListener(v -> { selected[0] = idx; repaint.run(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            wrap.addView(item, lp);
            items[i] = item;
        }
        repaint.run();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        wrap.setLayoutParams(lp);
        return wrap;
    }

    private View categoryGrid(EditText purpose) {
        String[] names = {"餐饮", "购物", "交通", "日用", "娱乐", "医疗", "学习", "其他"};
        String[] icons = {"🍴", "▣", "▰", "⌂", "♬", "+", "▤", "•••"};
        int[] colors = {RED, BLUE, Color.rgb(61, 151, 221), PURPLE, ORANGE, GREEN, Color.rgb(79, 137, 213), PURPLE};
        int[] soft = {RED_SOFT, BLUE_SOFT, dark ? Color.rgb(28, 61, 82) : Color.rgb(233, 247, 255), PURPLE_SOFT, ORANGE_SOFT, GREEN_SOFT, BLUE_SOFT, PURPLE_SOFT};
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        for (int r = 0; r < 2; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 4; c++) {
                int idx = r * 4 + c;
                LinearLayout item = new LinearLayout(this);
                item.setOrientation(LinearLayout.VERTICAL);
                item.setGravity(Gravity.CENTER);
                TextView icon = text(icons[idx], 17, true, colors[idx]);
                icon.setGravity(Gravity.CENTER);
                icon.setBackground(rounded(soft[idx], 0, 16));
                item.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));
                TextView name = text(names[idx], 11, idx == 0, idx == 0 ? RED : TEXT);
                name.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                nlp.setMargins(0, dp(5), 0, 0);
                item.addView(name, nlp);
                item.setOnClickListener(v -> purpose.setText(names[idx]));
                row.addView(item, new LinearLayout.LayoutParams(0, dp(80), 1f));
            }
            outer.addView(row);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        outer.setBackground(rounded(CARD, LINE, 18));
        outer.setPadding(dp(6), dp(9), dp(6), dp(8));
        outer.setLayoutParams(lp);
        return outer;
    }

    private void showAnalysis() {
        selectNav(2);
        LinearLayout body = pageBody();
        body.addView(simpleTopBar("图表分析", null));
        final int[] period = {0};
        LinearLayout chartHost = new LinearLayout(this);
        chartHost.setOrientation(LinearLayout.VERTICAL);
        body.addView(periodTabs(period, chartHost));
        body.addView(chartHost);
        loadAnalysis(chartHost, period[0]);
        mount(body);
    }

    private View periodTabs(int[] selected, LinearLayout host) {
        String[] labels = {"本期", "本周", "本月", "自定义"};
        TextView[] items = new TextView[labels.length];
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Runnable repaint = () -> {
            for (int i = 0; i < items.length; i++) {
                boolean on = selected[0] == i;
                items[i].setTextColor(on ? Color.WHITE : MUTED);
                items[i].setBackground(rounded(on ? BLUE : INPUT_BG, 0, 14));
                items[i].setTypeface(Typeface.DEFAULT, on ? Typeface.BOLD : Typeface.NORMAL);
            }
        };
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView item = text(labels[i], 11, false, MUTED);
            item.setGravity(Gravity.CENTER);
            item.setOnClickListener(v -> {
                if (idx == 3) {
                    chooseCustomRange(() -> {
                        selected[0] = 3; repaint.run(); loadAnalysis(host, 3);
                    });
                } else {
                    selected[0] = idx; repaint.run(); loadAnalysis(host, idx);
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(36), 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            row.addView(item, lp);
            items[i] = item;
        }
        repaint.run();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(10));
        row.setLayoutParams(lp);
        return row;
    }

    private void chooseCustomRange(Runnable done) {
        Calendar start = Calendar.getInstance();
        start.add(Calendar.DAY_OF_MONTH, -30);
        new DatePickerDialog(this, (v, y, m, d) -> {
            customStart = Calendar.getInstance(); customStart.set(y, m, d); zeroTime(customStart);
            Calendar endDefault = Calendar.getInstance();
            new DatePickerDialog(this, (v2, y2, m2, d2) -> {
                customEnd = Calendar.getInstance(); customEnd.set(y2, m2, d2); zeroTime(customEnd); customEnd.add(Calendar.DAY_OF_MONTH, 1);
                if (customEnd.before(customStart)) { toast("结束日期不能早于开始日期"); return; }
                done.run();
            }, endDefault.get(Calendar.YEAR), endDefault.get(Calendar.MONTH), endDefault.get(Calendar.DAY_OF_MONTH)).show();
        }, start.get(Calendar.YEAR), start.get(Calendar.MONTH), start.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void loadAnalysis(LinearLayout host, int period) {
        host.removeAllViews();
        long[] range = rangeFor(period);
        FinanceDb.Summary s = db.getSummary(range[0], range[1]);
        Map<String, Double> map = db.getPurposeTotals(FinanceDb.TYPE_EXPENSE, range[0], range[1]);

        LinearLayout donutCard = card();
        donutCard.addView(text("支出构成", 15, true, TEXT));
        LinearLayout donutRow = new LinearLayout(this);
        donutRow.setOrientation(LinearLayout.HORIZONTAL);
        donutRow.setGravity(Gravity.CENTER_VERTICAL);
        List<Double> values = new ArrayList<>();
        List<String> names = new ArrayList<>();
        int count = 0;
        double other = 0;
        for (Map.Entry<String, Double> e : map.entrySet()) {
            if (count < 5) { names.add(e.getKey()); values.add(e.getValue()); count++; }
            else other += e.getValue();
        }
        if (other > 0) { names.add("其他"); values.add(other); }
        DonutChartView donut = new DonutChartView(values, s.expense);
        donutRow.addView(donut, new LinearLayout.LayoutParams(dp(150), dp(150)));
        LinearLayout legend = new LinearLayout(this);
        legend.setOrientation(LinearLayout.VERTICAL);
        legend.setPadding(dp(10), 0, 0, 0);
        double total = s.expense;
        int[] colors = chartColors();
        for (int i = 0; i < names.size(); i++) legend.addView(legendRow(names.get(i), values.get(i), total, colors[i % colors.length]));
        if (names.isEmpty()) legend.addView(text("暂无支出数据", 12, false, MUTED));
        donutRow.addView(legend, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        donutCard.addView(donutRow);
        host.addView(donutCard, cardParams(0));

        LinearLayout trend = card();
        trend.addView(text("每日支出趋势", 15, true, TEXT));
        TextView sub = text(periodName(period) + "  ·  支出 ¥" + money.format(s.expense), 11, false, MUTED);
        sub.setPadding(0, dp(3), 0, dp(8));
        trend.addView(sub);
        trend.addView(new BarChartView(dailySeries(range[0], range[1])), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)));
        host.addView(trend, cardParams(10));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.addView(actionButton("数据统计", BLUE, BLUE_SOFT, this::showStats), weightMargin(4));
        actions.addView(actionButton("用途排行", GREEN, GREEN_SOFT, this::showRanking), weightMargin(4));
        host.addView(actions, cardParams(10));
    }

    private View legendRow(String name, double value, double total, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        View dot = new View(this); dot.setBackground(rounded(color, 0, 99));
        row.addView(dot, new LinearLayout.LayoutParams(dp(7), dp(7)));
        TextView n = text("  " + name, 11, false, TEXT);
        row.addView(n, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(text(total > 0 ? new DecimalFormat("0%").format(value / total) : "0%", 11, true, MUTED));
        row.setPadding(0, dp(4), 0, dp(4));
        return row;
    }

    private void showBudget() {
        LinearLayout body = pageBody();
        body.addView(backTopBar("预算管理", this::showHome));
        Calendar now = Calendar.getInstance();
        long[] cycle = cycleRange(now);
        FinanceDb.Summary s = db.getSummary(cycle[0], cycle[1]);
        FinanceDb.Plan p = getPlanForCycle(now);

        LinearLayout period = rowCard(BLUE_SOFT);
        period.addView(iconBubble("▣", BLUE, dark ? Color.rgb(34, 65, 95) : Color.WHITE), new LinearLayout.LayoutParams(dp(38), dp(38)));
        LinearLayout pi = new LinearLayout(this); pi.setOrientation(LinearLayout.VERTICAL); pi.setPadding(dp(10),0,0,0);
        pi.addView(text("当前周期", 11, true, BLUE)); pi.addView(text(displayCycle(now), 13, true, TEXT));
        period.addView(pi, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView modify = text("修改周期", 11, true, BLUE); modify.setPadding(dp(10), dp(6), dp(10), dp(6)); modify.setBackground(rounded(dark ? Color.rgb(35,65,92) : Color.WHITE,0,12)); modify.setOnClickListener(v->showCycleSettings());
        period.addView(modify);
        body.addView(period, cardParams(0));

        LinearLayout totalCard = card();
        totalCard.setClickable(true);
        totalCard.setFocusable(true);
        totalCard.setBackground(ripple(dark ? Color.rgb(28,31,42) : Color.WHITE, 0, 20));
        totalCard.setOnClickListener(v -> editTotalPlan(now, this::showBudget));
        LinearLayout line = new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL); line.setGravity(Gravity.CENTER_VERTICAL);
        line.addView(text("总预算", 13, true, TEXT), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView setBudget = text(p.budget > 0 ? "修改预算" : "设置预算", 11, true, BLUE);
        setBudget.setPadding(dp(10), dp(6), dp(10), dp(6));
        setBudget.setBackground(rounded(dark ? Color.rgb(35,65,92) : BLUE_SOFT, 0, 12));
        setBudget.setOnClickListener(v -> editTotalPlan(now, this::showBudget));
        line.addView(setBudget);
        totalCard.addView(line);
        TextView big = text(p.budget > 0 ? "¥" + money.format(p.budget) : "未设置", 25, true, TEXT); big.setPadding(0, dp(8),0,0); totalCard.addView(big);
        double totalRate = p.budget > 0 ? s.expense / p.budget : 0;
        TextView rateText = text(p.budget > 0 ? "已使用 " + new DecimalFormat("0%").format(Math.min(1, totalRate)) : "点击此卡设置本周期总预算", 10, false, MUTED);
        rateText.setPadding(0, dp(2), 0, dp(2)); totalCard.addView(rateText);
        totalCard.addView(progressLine(totalRate, GREEN), progressParams());
        TextView foot = text("已用 ¥" + money.format(s.expense) + (p.budget > 0 ? "       剩余 ¥" + money.format(Math.max(0, p.budget - s.expense)) : ""), 11, false, MUTED); foot.setPadding(0,dp(8),0,0); totalCard.addView(foot);
        body.addView(totalCard, cardParams(10));

        body.addView(sectionLabel("分类预算", "+ 添加分类"));
        Map<String, Double> saved = getCategoryBudgetsForCycle(now);
        String[] defaults = {"餐饮", "购物", "交通", "日用"};
        if (saved.isEmpty()) {
            double base = p.budget > 0 ? p.budget : 0;
            saved = new LinkedHashMap<>();
            saved.put("餐饮", base * .30); saved.put("购物", base * .20); saved.put("交通", base * .12); saved.put("日用", base * .12);
        }
        Map<String, Double> spent = db.getPurposeTotals(FinanceDb.TYPE_EXPENSE, cycle[0], cycle[1]);
        for (Map.Entry<String, Double> e : saved.entrySet()) {
            double used = spent.containsKey(e.getKey()) ? spent.get(e.getKey()) : 0;
            body.addView(categoryBudgetRow(now, e.getKey(), e.getValue(), used), cardParams(7));
        }
        TextView add = text("＋ 添加分类预算", 13, true, BLUE); add.setGravity(Gravity.CENTER); add.setBackground(ripple(BLUE_SOFT,0,16)); add.setOnClickListener(v->editCategoryBudget(now, null, 0));
        body.addView(add, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        mount(body);
    }

    private View categoryBudgetRow(Calendar now, String category, double budget, double used) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = categoryIcon(category, 38); top.addView(icon, new LinearLayout.LayoutParams(dp(38), dp(38)));
        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(dp(10),0,0,0);
        info.addView(text(category, 13, true, TEXT));
        info.addView(text("¥" + money.format(used) + " 已用", 10, false, MUTED));
        top.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView right = text(budget > 0 ? "¥" + money.format(budget) : "未设置", 13, true, TEXT); right.setOnClickListener(v->editCategoryBudget(now, category, budget)); top.addView(right);
        c.addView(top);
        c.addView(progressLine(budget > 0 ? used / budget : 0, used > budget && budget > 0 ? RED : GREEN), progressParams());
        return c;
    }

    private void editTotalPlan(Calendar cycle) {
        editTotalPlan(cycle, this::showBudget);
    }

    private void editTotalPlan(Calendar cycle, Runnable afterSave) {
        FinanceDb.Plan p = getPlanForCycle(cycle);
        LinearLayout box = dialogForm();

        TextView budgetLabel = text("本周期总预算", 11, true, TEXT);
        budgetLabel.setPadding(0, dp(2), 0, dp(6));
        box.addView(budgetLabel);
        EditText budget = edit("例如 3000");
        budget.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        if (p.budget > 0) budget.setText(stripZero(p.budget));
        box.addView(budget, fieldParamsNoTop());

        TextView targetLabel = text("净结余目标（可不填）", 11, true, TEXT);
        targetLabel.setPadding(0, dp(13), 0, dp(6));
        box.addView(targetLabel);
        EditText target = edit("例如 1500");
        target.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        if (p.target > 0) target.setText(stripZero(p.target));
        box.addView(target, fieldParamsNoTop());

        TextView keyHint = text("保存到：" + displayCycleFull(cycle), 9, false, MUTED);
        keyHint.setPadding(0, dp(11), 0, 0);
        box.addView(keyHint);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(p.budget > 0 ? "修改预算" : "设置预算")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            double b = parseNonNegative(budget.getText().toString());
            double t = parseNonNegative(target.getText().toString());
            if (b <= 0) {
                budget.setError("请输入大于 0 的总预算");
                budget.requestFocus();
                return;
            }
            if (t < 0) {
                target.setError("金额格式不正确");
                target.requestFocus();
                return;
            }
            if (!savePlanForCycle(cycle, b, t)) {
                toast("预算保存失败，请重试");
                return;
            }
            FinanceDb.Plan verify = getPlanForCycle(cycle);
            if (Math.abs(verify.budget - b) > 0.001 || Math.abs(verify.target - t) > 0.001) {
                toast("预算写入校验失败，请重试");
                return;
            }
            dialog.dismiss();
            toast("已保存本周期预算 ¥" + money.format(b));
            if (afterSave != null) afterSave.run();
        }));
        dialog.show();
    }

    private void editCategoryBudget(Calendar cycle, String category, double current) {
        LinearLayout box = dialogForm();
        EditText name = edit("分类名称"); if(category!=null) name.setText(category);
        EditText amount = edit("预算金额"); amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); if(current>0) amount.setText(stripZero(current));
        box.addView(name); box.addView(amount, fieldParams());
        new AlertDialog.Builder(this).setTitle(category==null?"添加分类预算":"修改分类预算").setView(box).setNegativeButton("取消",null).setPositiveButton("保存",(d,w)->{
            double v=parseNonNegative(amount.getText().toString()); if(name.getText().toString().trim().isEmpty()||v<0){toast("请填写正确的分类和金额");return;}
            saveCategoryBudgetForCycle(cycle,name.getText().toString(),v); showBudget();
        }).show();
    }

    private void showRecords() {
        LinearLayout body = pageBody();
        body.addView(backTopBar("账单列表", this::showHome));
        final int[] selected = {0};
        LinearLayout listHost = new LinearLayout(this); listHost.setOrientation(LinearLayout.VERTICAL);
        body.addView(recordFilters(selected, listHost));
        body.addView(listHost);
        loadRecords(listHost, selected[0]);
        mount(body);
    }

    private View recordFilters(int[] selected, LinearLayout host) {
        String[] labels={"全部","支出","收入","负债"}; TextView[] items=new TextView[4];
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Runnable repaint=()->{for(int i=0;i<4;i++){boolean on=selected[0]==i;items[i].setTextColor(on?Color.WHITE:MUTED);items[i].setBackground(rounded(on?BLUE:INPUT_BG,0,14));items[i].setTypeface(Typeface.DEFAULT,on?Typeface.BOLD:Typeface.NORMAL);}};
        for(int i=0;i<4;i++){final int idx=i;TextView t=text(labels[i],11,false,MUTED);t.setGravity(Gravity.CENTER);t.setOnClickListener(v->{selected[0]=idx;repaint.run();loadRecords(host,idx);});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(36),1f);lp.setMargins(dp(2),0,dp(2),0);row.addView(t,lp);items[i]=t;} repaint.run();
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);lp.setMargins(0,0,0,dp(10));row.setLayoutParams(lp);return row;
    }

    private void loadRecords(LinearLayout host,int filter){
        host.removeAllViews();String type=filter==1?FinanceDb.TYPE_EXPENSE:filter==2?FinanceDb.TYPE_INCOME:filter==3?FinanceDb.TYPE_DEBT:null;
        List<FinanceDb.Record> rows=db.getRecent(type,400); if(rows.isEmpty()){TextView e=text("暂无账单",13,false,MUTED);e.setGravity(Gravity.CENTER);e.setPadding(0,dp(40),0,0);host.addView(e);return;}
        String last=""; for(FinanceDb.Record r:rows){String day=dateFmt.format(new Date(r.occurredAt)); if(!day.equals(last)){Calendar c=Calendar.getInstance();c.setTimeInMillis(r.occurredAt);TextView h=text(dayFmt.format(new Date(r.occurredAt))+"  (周"+weekZh(c)+")",11,true,MUTED);h.setPadding(dp(2),dp(10),0,dp(5));host.addView(h);last=day;} host.addView(recordListRow(r));}
    }

    private View recordListRow(FinanceDb.Record r){
        LinearLayout c=card();c.setPadding(dp(14),dp(11),dp(14),dp(11));
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(categoryIcon(r.purpose,38),new LinearLayout.LayoutParams(dp(38),dp(38)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(10),0,0,0);info.addView(text(r.purpose,13,true,TEXT));info.addView(text(timeFmt.format(new Date(r.occurredAt))+(r.note==null||r.note.isEmpty()?"":"  ·  "+r.note),10,false,MUTED));row.addView(info,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));
        String sign=FinanceDb.TYPE_INCOME.equals(r.type)?"+":"-";TextView amount=text(sign+"¥"+money.format(r.amount),13,true,typeColor(r.type));row.addView(amount);c.addView(row);
        c.setOnLongClickListener(v->{new AlertDialog.Builder(this).setTitle("删除这笔账？").setMessage(r.purpose+"  ¥"+money.format(r.amount)).setNegativeButton("取消",null).setPositiveButton("删除",(d,w)->{db.deleteRecord(r.id);showRecords();}).show();return true;});
        return c;
    }

    private void showStats(){
        LinearLayout body=pageBody();body.addView(backTopBar("数据统计",this::showAnalysis));final int[] period={0};LinearLayout host=new LinearLayout(this);host.setOrientation(LinearLayout.VERTICAL);body.addView(statsPeriodTabs(period,host));body.addView(host);loadStats(host,0);mount(body);
    }

    private View statsPeriodTabs(int[] selected, LinearLayout host) {
        String[] labels = {"本期", "本周", "本月", "自定义"};
        TextView[] items = new TextView[labels.length];
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Runnable repaint = () -> {
            for (int i = 0; i < items.length; i++) {
                boolean on = selected[0] == i;
                items[i].setTextColor(on ? Color.WHITE : MUTED);
                items[i].setBackground(rounded(on ? BLUE : INPUT_BG, 0, 14));
                items[i].setTypeface(Typeface.DEFAULT, on ? Typeface.BOLD : Typeface.NORMAL);
            }
        };
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView item = text(labels[i], 11, false, MUTED); item.setGravity(Gravity.CENTER);
            item.setOnClickListener(v -> {
                if (idx == 3) {
                    chooseCustomRange(() -> { selected[0] = 3; repaint.run(); loadStats(host, 3); });
                } else { selected[0] = idx; repaint.run(); loadStats(host, idx); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(36), 1f); lp.setMargins(dp(2),0,dp(2),0);
            row.addView(item, lp); items[i] = item;
        }
        repaint.run();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(0,0,0,dp(10)); row.setLayoutParams(lp);
        return row;
    }

    private void loadStats(LinearLayout host,int period){
        host.removeAllViews();long[] range=rangeFor(period);FinanceDb.Summary s=db.getSummary(range[0],range[1]);long days=Math.max(1,(range[1]-range[0])/86400000L);FinanceDb.Record max=db.getLargestRecord(FinanceDb.TYPE_EXPENSE,range[0],range[1]);
        LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout r1=new LinearLayout(this);r1.setOrientation(LinearLayout.HORIZONTAL);r1.addView(statTile("支出","¥"+money.format(s.expense),RED,"本期累计"),weightMargin(4));r1.addView(statTile("收入","¥"+money.format(s.income),GREEN,"本期累计"),weightMargin(4));
        LinearLayout r2=new LinearLayout(this);r2.setOrientation(LinearLayout.HORIZONTAL);r2.setPadding(0,dp(8),0,0);r2.addView(statTile("日均支出","¥"+money.format(s.expense/days),ORANGE,"按自然日计算"),weightMargin(4));r2.addView(statTile("最大单笔",max==null?"¥0.00":"¥"+money.format(max.amount),BLUE,max==null?"暂无记录":max.purpose),weightMargin(4));grid.addView(r1);grid.addView(r2);host.addView(grid);
        LinearLayout net=card();net.addView(text("净结余",13,true,TEXT));TextView big=text("¥"+money.format(s.net()),27,true,s.net()>=0?GREEN:RED);big.setPadding(0,dp(6),0,0);net.addView(big);net.addView(text("收入 - 支出 - 负债",11,false,MUTED));host.addView(net,cardParams(10));
    }

    private View statTile(String title,String value,int color,String foot){
        LinearLayout c=card();c.setPadding(dp(14),dp(13),dp(14),dp(13));c.addView(text(title,11,true,MUTED));TextView v=text(value,19,true,color);v.setPadding(0,dp(5),0,dp(4));c.addView(v);c.addView(text(foot,10,false,MUTED));return c;
    }

    private void showRanking(){
        LinearLayout body=pageBody();body.addView(backTopBar("用途排行",this::showAnalysis));final int[] type={0};LinearLayout host=new LinearLayout(this);host.setOrientation(LinearLayout.VERTICAL);
        String[] labels={"支出排行","收入排行","负债排行"};TextView[] items=new TextView[3];LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);Runnable repaint=()->{for(int i=0;i<3;i++){boolean on=type[0]==i;items[i].setTextColor(on?Color.WHITE:MUTED);items[i].setBackground(rounded(on?(i==0?BLUE:i==1?GREEN:ORANGE):INPUT_BG,0,14));}};for(int i=0;i<3;i++){final int idx=i;TextView t=text(labels[i],11,false,MUTED);t.setGravity(Gravity.CENTER);t.setOnClickListener(v->{type[0]=idx;repaint.run();loadRanking(host,idx);});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(38),1f);lp.setMargins(dp(2),0,dp(2),0);tabs.addView(t,lp);items[i]=t;}repaint.run();body.addView(tabs);body.addView(host);loadRanking(host,0);mount(body);
    }

    private void loadRanking(LinearLayout host,int typeIdx){
        host.removeAllViews();long[] range=cycleRange(Calendar.getInstance());String type=typeIdx==0?FinanceDb.TYPE_EXPENSE:typeIdx==1?FinanceDb.TYPE_INCOME:FinanceDb.TYPE_DEBT;int color=typeIdx==0?BLUE:typeIdx==1?GREEN:ORANGE;Map<String,Double> map=db.getPurposeTotals(type,range[0],range[1]);if(map.isEmpty()){TextView e=text("本周期暂无数据",13,false,MUTED);e.setGravity(Gravity.CENTER);e.setPadding(0,dp(40),0,0);host.addView(e);return;}double max=0;for(double v:map.values())max=Math.max(max,v);int rank=1;for(Map.Entry<String,Double> e:map.entrySet()){LinearLayout c=card();c.setPadding(dp(12),dp(10),dp(12),dp(10));LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.HORIZONTAL);line.setGravity(Gravity.CENTER_VERTICAL);TextView no=text(String.valueOf(rank),11,true,rank<=3?Color.WHITE:MUTED);no.setGravity(Gravity.CENTER);no.setBackground(rounded(rank==1?RED:rank==2?ORANGE:rank==3?BLUE:INPUT_BG,0,99));line.addView(no,new LinearLayout.LayoutParams(dp(28),dp(28)));TextView name=text(e.getKey(),13,true,TEXT);name.setPadding(dp(10),0,0,0);line.addView(name,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));line.addView(text("¥"+money.format(e.getValue()),13,true,TEXT));c.addView(line);c.addView(progressLine(max==0?0:e.getValue()/max,color),progressParams());host.addView(c,cardParams(7));rank++;if(rank>20)break;}
    }

    private void showSettings(){
        selectNav(3);
        LinearLayout body=pageBody();
        body.addView(simpleTopBar("设置",null));
        body.addView(settingsRow("▣","记账周期",cycleSettingsSubtitle(),this::showCycleSettings),cardParams(0));
        body.addView(settingsRow("☷","分类预算","设置各用途消费额度",this::showBudget),cardParams(7));
        body.addView(settingsRow("↥","数据备份","导出 Moeny Board 备份文件",this::backupData),cardParams(7));
        body.addView(settingsRow("↧","数据恢复","从备份文件恢复",this::restoreData),cardParams(7));
        body.addView(settingsRow("⇩","导出数据","导出 CSV 账单",this::exportCsv),cardParams(7));
        body.addView(settingsRow("◐","主题设置",themeLabel(),this::showThemeDialog),cardParams(7));
        body.addView(settingsRow("ⓘ","关于我们","Moeny Board v" + appVersionName() + " · 陈开开开发",()->new AlertDialog.Builder(this)
                .setTitle("Moeny Board v" + appVersionName())
                .setMessage("一个完全离线、本地存储的个人记账 App。\n\n支持按月循环周期和自定义日期周期。\n点击首页紫色预算卡可直接设置本周期总预算；点击每日消费趋势图可查看分类与逐笔消费。\n数据只保存在你的手机。\n\n本软件由陈开开开发。\n版本：" + appVersionName() + " (" + appVersionCode() + ")")
                .setPositiveButton("知道了",null).show()),cardParams(7));
        TextView versionFoot = text("当前安装版本：v" + appVersionName() + "  ·  build " + appVersionCode(), 10, false, MUTED);
        versionFoot.setGravity(Gravity.CENTER);
        versionFoot.setPadding(0, dp(14), 0, dp(3));
        body.addView(versionFoot);
        mount(body);
    }

    private View settingsRow(String icon,String title,String sub,Runnable action){
        LinearLayout c=card();c.setPadding(dp(14),dp(12),dp(14),dp(12));LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);TextView ico=text(icon,17,true,BLUE);ico.setGravity(Gravity.CENTER);ico.setBackground(rounded(BLUE_SOFT,0,13));row.addView(ico,new LinearLayout.LayoutParams(dp(38),dp(38)));LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(11),0,0,0);info.addView(text(title,13,true,TEXT));info.addView(text(sub,10,false,MUTED));row.addView(info,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));row.addView(text("›",22,false,MUTED));c.addView(row);c.setOnClickListener(v->action.run());return c;
    }

    private void showCycleSettings(){
        LinearLayout body=pageBody();
        body.addView(backTopBar("周期设置",this::showSettings));

        LinearLayout monthly = card();
        monthly.setPadding(dp(16),dp(15),dp(16),dp(15));
        LinearLayout mh = new LinearLayout(this); mh.setOrientation(LinearLayout.HORIZONTAL); mh.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout mi = new LinearLayout(this); mi.setOrientation(LinearLayout.VERTICAL);
        mi.addView(text("按月循环",14,true,TEXT));
        mi.addView(text("例如：每月 15 日 → 次月 15 日",11,false,MUTED));
        mh.addView(mi,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));
        TextView mt = text(!isCustomCycle() ? "使用中" : "设置",11,true,!isCustomCycle()?GREEN:BLUE);
        mt.setPadding(dp(10),dp(6),dp(10),dp(6));
        mt.setBackground(glassTintDrawable(!isCustomCycle()?GREEN_SOFT:BLUE_SOFT,12));
        mh.addView(mt); monthly.addView(mh);
        TextView mp = text(monthlyCyclePreview(),12,true,BLUE); mp.setPadding(0,dp(12),0,0); monthly.addView(mp);
        monthly.setOnClickListener(v->showMonthlyCycleEditor());
        body.addView(monthly,cardParams(0));

        LinearLayout custom = card();
        custom.setPadding(dp(16),dp(15),dp(16),dp(15));
        LinearLayout ch = new LinearLayout(this); ch.setOrientation(LinearLayout.HORIZONTAL); ch.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout ci = new LinearLayout(this); ci.setOrientation(LinearLayout.VERTICAL);
        ci.addView(text("自定义日期",14,true,TEXT));
        ci.addView(text("手动选择一个完整的开始日和结束日",11,false,MUTED));
        ch.addView(ci,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));
        TextView ct = text(isCustomCycle() ? "使用中" : "设置",11,true,isCustomCycle()?GREEN:BLUE);
        ct.setPadding(dp(10),dp(6),dp(10),dp(6));
        ct.setBackground(glassTintDrawable(isCustomCycle()?GREEN_SOFT:BLUE_SOFT,12));
        ch.addView(ct); custom.addView(ch);
        TextView cp = text(customCyclePreview(),12,true,PURPLE); cp.setPadding(0,dp(12),0,0); custom.addView(cp);
        custom.setOnClickListener(v->showCustomCycleEditor());
        body.addView(custom,cardParams(10));

        LinearLayout current=card();
        current.setBackground(glassTintDrawable(BLUE_SOFT,18));
        current.addView(text("当前记账周期",12,true,BLUE));
        TextView range=text(displayCycleFull(Calendar.getInstance()),15,true,TEXT);
        range.setPadding(0,dp(7),0,dp(5));
        range.setLineSpacing(dp(2),1.05f);
        current.addView(range);
        current.addView(text("预算、看板、用途排行和本期统计都会按这个周期计算。",11,false,MUTED));
        body.addView(current,cardParams(10));
        mount(body);
    }

    private void showMonthlyCycleEditor(){
        LinearLayout body=pageBody();
        body.addView(backTopBar("按月循环周期",this::showCycleSettings));
        final int[] day={cycleDay()};
        LinearLayout c=card();
        c.addView(text("每月起始日",13,true,TEXT));
        TextView number=text(String.valueOf(day[0]),36,true,TEXT);
        number.setGravity(Gravity.CENTER);
        number.setMinHeight(dp(70));
        LinearLayout adjust=new LinearLayout(this); adjust.setOrientation(LinearLayout.HORIZONTAL); adjust.setGravity(Gravity.CENTER_VERTICAL);
        TextView minus=outlineButton("−"); TextView plus=outlineButton("＋");
        adjust.addView(minus,new LinearLayout.LayoutParams(dp(54),dp(50)));
        adjust.addView(number,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));
        adjust.addView(plus,new LinearLayout.LayoutParams(dp(54),dp(50)));
        c.addView(adjust);
        TextView unit=text("日",13,true,MUTED); unit.setGravity(Gravity.CENTER); c.addView(unit);
        final TextView preview=text(monthlyPreviewForDay(day[0]),12,false,MUTED); preview.setPadding(0,dp(14),0,0); preview.setGravity(Gravity.CENTER); c.addView(preview);
        Runnable refresh=()->{number.setText(String.valueOf(day[0]));preview.setText(monthlyPreviewForDay(day[0]));};
        minus.setOnClickListener(v->{day[0]=Math.max(1,day[0]-1);refresh.run();});
        plus.setOnClickListener(v->{day[0]=Math.min(28,day[0]+1);refresh.run();});
        body.addView(c,cardParams(0));
        TextView save=filledButton("使用按月循环周期",BLUE);
        save.setOnClickListener(v->{prefs.edit().putString("cycle_mode","monthly").putInt("cycle_start_day",day[0]).apply();toast("周期已更新");showCycleSettings();});
        LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(52));slp.setMargins(0,dp(12),0,0);body.addView(save,slp);
        mount(body);
    }

    private void showCustomCycleEditor(){
        long[] current=cycleRange(Calendar.getInstance());
        final Calendar[] start={Calendar.getInstance()}; start[0].setTimeInMillis(isCustomCycle()?customCycleStartMs():current[0]); zeroTime(start[0]);
        final Calendar[] end={Calendar.getInstance()}; end[0].setTimeInMillis(isCustomCycle()?customCycleEndMs():current[1]); zeroTime(end[0]);
        LinearLayout body=pageBody();
        body.addView(backTopBar("自定义日期周期",this::showCycleSettings));
        LinearLayout c=card();
        c.addView(text("选择周期边界",13,true,TEXT));
        TextView hint=text("结束日按 00:00 作为下一个周期边界，例如 8月15日 → 9月15日。",11,false,MUTED);hint.setPadding(0,dp(5),0,dp(12));c.addView(hint);
        TextView startBtn=outlineButton(formatFullDate(start[0].getTimeInMillis())+" 00:00");
        TextView endBtn=outlineButton(formatFullDate(end[0].getTimeInMillis())+" 00:00");
        c.addView(text("开始",11,true,BLUE)); c.addView(startBtn,fieldParams());
        TextView endLabel=text("结束",11,true,PURPLE); endLabel.setPadding(0,dp(12),0,0); c.addView(endLabel); c.addView(endBtn,fieldParams());
        startBtn.setOnClickListener(v->showDatePicker(start[0],picked->{start[0]=picked;startBtn.setText(formatFullDate(start[0].getTimeInMillis())+" 00:00");}));
        endBtn.setOnClickListener(v->showDatePicker(end[0],picked->{end[0]=picked;endBtn.setText(formatFullDate(end[0].getTimeInMillis())+" 00:00");}));
        body.addView(c,cardParams(0));
        TextView save=filledButton("使用这个自定义周期",PURPLE);
        save.setOnClickListener(v->{
            long sMs=start[0].getTimeInMillis(),eMs=end[0].getTimeInMillis();
            if(eMs<=sMs){toast("结束日期必须晚于开始日期");return;}
            prefs.edit().putString("cycle_mode","custom").putLong("custom_cycle_start",sMs).putLong("custom_cycle_end",eMs).apply();
            toast("自定义周期已保存");showCycleSettings();
        });
        LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(52));slp.setMargins(0,dp(12),0,0);body.addView(save,slp);
        mount(body);
    }

    private interface CalendarPicked { void onPicked(Calendar c); }
    private void showDatePicker(Calendar initial,CalendarPicked done){
        new DatePickerDialog(this,(v,y,m,d)->{Calendar c=Calendar.getInstance();c.set(y,m,d);zeroTime(c);done.onPicked(c);},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void backupData(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"Moeny_Board_backup_"+dateFmt.format(new Date())+".json");startActivityForResult(i,REQ_BACKUP);
    }
    private void restoreData(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");startActivityForResult(i,REQ_RESTORE);}
    private void exportCsv(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"Moeny_Board_账单_"+dateFmt.format(new Date())+".csv");startActivityForResult(i,REQ_CSV);}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();try{if(requestCode==REQ_BACKUP){writeUri(uri,db.exportJson());toast("备份完成");}else if(requestCode==REQ_CSV){writeUri(uri,"\uFEFF"+db.exportCsv());toast("CSV 已导出");}else if(requestCode==REQ_RESTORE){String json=readUri(uri);new AlertDialog.Builder(this).setTitle("恢复备份？").setMessage("恢复会覆盖当前账目、预算和分类预算。").setNegativeButton("取消",null).setPositiveButton("恢复",(d,w)->{try{db.importJson(json);toast("恢复完成");showHome();}catch(Exception e){toast("恢复失败："+e.getMessage());}}).show();}}catch(Exception e){toast("操作失败："+e.getMessage());}}
    private void writeUri(Uri uri,String content)throws Exception{try(OutputStream os=getContentResolver().openOutputStream(uri)){if(os==null)throw new Exception("无法打开文件");os.write(content.getBytes(StandardCharsets.UTF_8));}}
    private String readUri(Uri uri)throws Exception{try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new Exception("无法打开文件");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString("UTF-8");}}

    private void showThemeDialog(){
        String[] labels={"浅色","深色","跟随系统"};String[] values={"light","dark","system"};String current=prefs.getString("theme","light");int checked=0;for(int i=0;i<values.length;i++)if(values[i].equals(current))checked=i;final int[] pick={checked};new AlertDialog.Builder(this).setTitle("主题设置").setSingleChoiceItems(labels,checked,(d,w)->pick[0]=w).setNegativeButton("取消",null).setPositiveButton("应用",(d,w)->{prefs.edit().putString("theme",values[pick[0]]).apply();applyPalette();applySystemBars();setContentView(buildRoot());showSettings();}).show();
    }

    private View sectionLabel(String title,String action){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);TextView t=text(title,14,true,TEXT);row.addView(t,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));if(action!=null){TextView a=text(action,11,true,BLUE);row.addView(a);}LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);lp.setMargins(dp(2),dp(9),dp(2),dp(7));row.setLayoutParams(lp);return row;}

    private View simpleTopBar(String title,Runnable trailing){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);TextView left=text(title,20,true,TEXT);row.addView(left,new LinearLayout.LayoutParams(0,dp(42),1f));if(trailing!=null){TextView b=text("⚙",20,false,TEXT);b.setGravity(Gravity.CENTER);b.setOnClickListener(v->trailing.run());row.addView(b,new LinearLayout.LayoutParams(dp(42),dp(42)));}LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);lp.setMargins(0,0,0,dp(12));row.setLayoutParams(lp);return row;}
    private View backTopBar(String title,Runnable back){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);TextView b=text("‹",29,false,TEXT);b.setGravity(Gravity.CENTER_VERTICAL);b.setOnClickListener(v->back.run());row.addView(b,new LinearLayout.LayoutParams(dp(36),dp(44)));TextView t=text(title,18,true,TEXT);t.setGravity(Gravity.CENTER);row.addView(t,new LinearLayout.LayoutParams(0,dp(44),1f));row.addView(new View(this),new LinearLayout.LayoutParams(dp(36),dp(44)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);lp.setMargins(0,0,0,dp(12));row.setLayoutParams(lp);return row;}

    private TextView settingField(String label,String value){TextView t=text(label+"                                      "+value,12,true,TEXT);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(14),0,dp(14),0);t.setBackground(ripple(INPUT_BG,0,14));return t;}
    private LinearLayout dialogForm(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),dp(8),dp(22),0);return box;}

    private long[] rangeFor(int period){Calendar now=Calendar.getInstance();if(period==0)return cycleRange(now);if(period==1)return weekRange(now);if(period==2)return monthRange(now);if(customStart!=null&&customEnd!=null)return new long[]{customStart.getTimeInMillis(),customEnd.getTimeInMillis()};return cycleRange(now);}
    private String periodName(int p){return p==0?"本期":p==1?"本周":p==2?"本月":"自定义";}

    private List<Double> dailySeries(long startMs,long endMs){List<Double> out=new ArrayList<>();Calendar c=Calendar.getInstance();c.setTimeInMillis(startMs);while(c.getTimeInMillis()<endMs&&out.size()<62){Calendar n=(Calendar)c.clone();n.add(Calendar.DAY_OF_MONTH,1);out.add(db.getSummary(c.getTimeInMillis(),Math.min(n.getTimeInMillis(),endMs)).expense);c=n;}return out;}

    private long[] cycleRange(Calendar source){
        if(isCustomCycle()){
            long start=customCycleStartMs(),end=customCycleEndMs();
            if(end>start)return new long[]{start,end};
        }
        Calendar s=cycleStart(source);Calendar e=(Calendar)s.clone();e.add(Calendar.MONTH,1);
        return new long[]{s.getTimeInMillis(),e.getTimeInMillis()};
    }

    private Calendar cycleStart(Calendar source){
        Calendar s=(Calendar)source.clone();zeroTime(s);int day=cycleDay();
        if(s.get(Calendar.DAY_OF_MONTH)<day)s.add(Calendar.MONTH,-1);
        int max=s.getActualMaximum(Calendar.DAY_OF_MONTH);s.set(Calendar.DAY_OF_MONTH,Math.min(day,max));zeroTime(s);return s;
    }

    private long[] weekRange(Calendar source){Calendar s=(Calendar)source.clone();int dow=s.get(Calendar.DAY_OF_WEEK);int delta=dow==Calendar.SUNDAY?-6:Calendar.MONDAY-dow;s.add(Calendar.DAY_OF_MONTH,delta);zeroTime(s);Calendar e=(Calendar)s.clone();e.add(Calendar.DAY_OF_MONTH,7);return new long[]{s.getTimeInMillis(),e.getTimeInMillis()};}
    private long[] monthRange(Calendar source){Calendar s=(Calendar)source.clone();s.set(Calendar.DAY_OF_MONTH,1);zeroTime(s);Calendar e=(Calendar)s.clone();e.add(Calendar.MONTH,1);return new long[]{s.getTimeInMillis(),e.getTimeInMillis()};}
    private int cycleDay(){return prefs==null?15:Math.max(1,Math.min(28,prefs.getInt("cycle_start_day",15)));}
    private boolean isCustomCycle(){return prefs!=null&&"custom".equals(prefs.getString("cycle_mode","monthly"))&&customCycleEndMs()>customCycleStartMs();}
    private long customCycleStartMs(){return prefs==null?0:prefs.getLong("custom_cycle_start",0);}
    private long customCycleEndMs(){return prefs==null?0:prefs.getLong("custom_cycle_end",0);}

    /**
     * v1.5 canonical storage key: derived only from the exact active cycle range.
     * This prevents home/budget/custom-cycle screens from accidentally reading different plan rows.
     */
    private String cycleStorageKey(Calendar source){
        long[] r = cycleRange(source);
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd", Locale.US);
        return "cycle-" + f.format(new Date(r[0])) + "-" + f.format(new Date(r[1]));
    }

    /** Legacy key used by v1.4.x and earlier. Kept only for migration / downgrade compatibility. */
    private String legacyCycleKey(Calendar source){
        if(isCustomCycle())return "custom-"+new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date(customCycleStartMs()))+"-"+new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date(customCycleEndMs()));
        Calendar s=cycleStart(source);
        if(cycleDay()==15)return String.format(Locale.US,"%04d-%02d",s.get(Calendar.YEAR),s.get(Calendar.MONTH)+1);
        return String.format(Locale.US,"%04d-%02d-%02d",s.get(Calendar.YEAR),s.get(Calendar.MONTH)+1,s.get(Calendar.DAY_OF_MONTH));
    }

    private FinanceDb.Plan getPlanForCycle(Calendar source){
        String canonical = cycleStorageKey(source);
        if (db.hasPlan(canonical)) return db.getPlan(canonical);
        String legacy = legacyCycleKey(source);
        if (!canonical.equals(legacy) && db.hasPlan(legacy)) {
            FinanceDb.Plan old = db.getPlan(legacy);
            db.savePlan(canonical, old.budget, old.target);
            return old;
        }
        return new FinanceDb.Plan(0, 0);
    }

    private boolean savePlanForCycle(Calendar source, double budget, double target){
        String canonical = cycleStorageKey(source);
        boolean ok = db.savePlan(canonical, budget, target);
        // Dual-write the old key so an accidental downgrade still sees the latest budget.
        String legacy = legacyCycleKey(source);
        if (!canonical.equals(legacy)) db.savePlan(legacy, budget, target);
        return ok;
    }

    private Map<String, Double> getCategoryBudgetsForCycle(Calendar source){
        String canonical = cycleStorageKey(source);
        Map<String, Double> current = db.getCategoryBudgets(canonical);
        if (!current.isEmpty()) return current;
        String legacy = legacyCycleKey(source);
        if (!canonical.equals(legacy)) {
            Map<String, Double> old = db.getCategoryBudgets(legacy);
            if (!old.isEmpty()) {
                for (Map.Entry<String, Double> e : old.entrySet()) db.saveCategoryBudget(canonical, e.getKey(), e.getValue());
                return old;
            }
        }
        return current;
    }

    private void saveCategoryBudgetForCycle(Calendar source, String category, double budget){
        String canonical = cycleStorageKey(source);
        db.saveCategoryBudget(canonical, category, budget);
        String legacy = legacyCycleKey(source);
        if (!canonical.equals(legacy)) db.saveCategoryBudget(legacy, category, budget);
    }

    private String displayCycle(Calendar source){
        long[] r=cycleRange(source);Calendar s=Calendar.getInstance();s.setTimeInMillis(r[0]);Calendar e=Calendar.getInstance();e.setTimeInMillis(r[1]);
        return String.format(Locale.CHINA,"%d月%d日 - %d月%d日",s.get(Calendar.MONTH)+1,s.get(Calendar.DAY_OF_MONTH),e.get(Calendar.MONTH)+1,e.get(Calendar.DAY_OF_MONTH));
    }

    private String compactCycle(Calendar source){
        long[] r=cycleRange(source);Calendar s=Calendar.getInstance();s.setTimeInMillis(r[0]);Calendar e=Calendar.getInstance();e.setTimeInMillis(r[1]);
        return String.format(Locale.US,"%02d/%02d - %02d/%02d",s.get(Calendar.MONTH)+1,s.get(Calendar.DAY_OF_MONTH),e.get(Calendar.MONTH)+1,e.get(Calendar.DAY_OF_MONTH));
    }

    private String displayCycleFull(Calendar source){
        long[] r=cycleRange(source);return formatFullDate(r[0])+" 00:00  →  "+formatFullDate(r[1])+" 00:00";
    }

    private String formatFullDate(long ms){return new SimpleDateFormat("yyyy年MM月dd日",Locale.CHINA).format(new Date(ms));}
    private String dayLabel(long ms){return new SimpleDateFormat("M月d日",Locale.CHINA).format(new Date(ms));}
    private String cycleModeLabel(){return isCustomCycle()?"自定义周期":"每月 "+cycleDay()+" 日切换新周期";}
    private String cycleSettingsSubtitle(){return isCustomCycle()?"自定义日期 · "+displayCycle(Calendar.getInstance()):"每月 "+cycleDay()+" 日开始";}
    private String monthlyCyclePreview(){return monthlyPreviewForDay(cycleDay());}
    private String monthlyPreviewForDay(int day){
        Calendar now=Calendar.getInstance();Calendar s=(Calendar)now.clone();zeroTime(s);if(s.get(Calendar.DAY_OF_MONTH)<day)s.add(Calendar.MONTH,-1);s.set(Calendar.DAY_OF_MONTH,Math.min(day,s.getActualMaximum(Calendar.DAY_OF_MONTH)));Calendar e=(Calendar)s.clone();e.add(Calendar.MONTH,1);e.set(Calendar.DAY_OF_MONTH,Math.min(day,e.getActualMaximum(Calendar.DAY_OF_MONTH)));
        return formatFullDate(s.getTimeInMillis())+" → "+formatFullDate(e.getTimeInMillis());
    }
    private String customCyclePreview(){return isCustomCycle()?formatFullDate(customCycleStartMs())+" → "+formatFullDate(customCycleEndMs()):"尚未设置自定义日期";}
    private int daysRemaining(Calendar source){long[] r=cycleRange(source);long diff=r[1]-source.getTimeInMillis();return Math.max(0,(int)Math.ceil(diff/86400000.0));}
    private void zeroTime(Calendar c){c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);}

    private int[] chartColors(){return new int[]{Color.rgb(255,79,66),PURPLE,BLUE,ORANGE,GREEN,Color.rgb(111,133,185)};}
    private int typeColor(String type){if(FinanceDb.TYPE_EXPENSE.equals(type))return RED;if(FinanceDb.TYPE_INCOME.equals(type))return GREEN;return ORANGE;}
    private int typeSoft(String type){if(FinanceDb.TYPE_EXPENSE.equals(type))return RED_SOFT;if(FinanceDb.TYPE_INCOME.equals(type))return GREEN_SOFT;return ORANGE_SOFT;}
    private String shortMoney(double v){double a=Math.abs(v);if(a>=10000)return (v<0?"-":"")+"¥"+new DecimalFormat("0.0").format(a/10000)+"w";return (v<0?"-":"")+"¥"+new DecimalFormat("#,##0").format(a);}
    private String stripZero(double d){return Math.rint(d)==d?String.valueOf((long)d):String.valueOf(d);}
    private double parseNonNegative(String s){String x=s.trim();if(x.isEmpty())return 0;try{double v=Double.parseDouble(x);return v>=0?v:-1;}catch(Exception e){return -1;}}
    private String weekZh(Calendar c){String[] names={"日","一","二","三","四","五","六"};return names[c.get(Calendar.DAY_OF_WEEK)-1];}
    private String appVersionName(){try{android.content.pm.PackageInfo i=getPackageManager().getPackageInfo(getPackageName(),0);return i.versionName==null?"?":i.versionName;}catch(Exception e){return "?";}}
    private int appVersionCode(){try{return getPackageManager().getPackageInfo(getPackageName(),0).versionCode;}catch(Exception e){return 0;}}
    private String themeLabel(){String v=prefs.getString("theme","light");return "dark".equals(v)?"深色":"system".equals(v)?"跟随系统":"浅色";}

    private TextView categoryIcon(String purpose,int size){String icon="•";int color=BLUE,soft=BLUE_SOFT;String p=purpose==null?"":purpose;if(p.contains("餐")||p.contains("吃")||p.contains("咖啡")){icon="🍴";color=RED;soft=RED_SOFT;}else if(p.contains("购")||p.contains("买")){icon="▣";color=PURPLE;soft=PURPLE_SOFT;}else if(p.contains("交通")||p.contains("地铁")||p.contains("车")){icon="▰";color=BLUE;soft=BLUE_SOFT;}else if(p.contains("日用")||p.contains("房")){icon="⌂";color=GREEN;soft=GREEN_SOFT;}else if(p.contains("医")){icon="+";color=GREEN;soft=GREEN_SOFT;}else if(p.contains("娱乐")){icon="♬";color=ORANGE;soft=ORANGE_SOFT;}TextView t=text(icon,size<=34?13:15,true,color);t.setGravity(Gravity.CENTER);t.setBackground(rounded(soft,0,99));return t;}
    private TextView iconBubble(String icon,int color,int fill){TextView t=text(icon,15,true,color);t.setGravity(Gravity.CENTER);t.setBackground(rounded(fill,0,12));return t;}

    private LinearLayout rowCard(int fill){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.HORIZONTAL);c.setGravity(Gravity.CENTER_VERTICAL);c.setPadding(dp(14),dp(12),dp(14),dp(12));c.setBackground(glassTintDrawable(fill,17));c.setElevation(dark?0:dp(2));return c;}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(16),dp(15),dp(16),dp(15));c.setBackground(glassDrawable(18));c.setElevation(dark?0:dp(3));return c;}
    private LinearLayout pageBody(){LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(18),dp(12),dp(18),dp(22));return body;}
    private void mount(LinearLayout body){
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.addView(body,new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        pageHost.removeAllViews();
        pageHost.addView(scroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        scroll.setAlpha(0f);
        scroll.setTranslationY(dp(8));
        scroll.animate().alpha(1f).translationY(0f).setDuration(220).setInterpolator(new DecelerateInterpolator()).start();
    }

    private TextView text(String s,int sp,boolean bold,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));t.setIncludeFontPadding(false);return t;}
    private EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(TEXT);e.setTextSize(13);e.setSingleLine(true);e.setPadding(dp(14),0,dp(14),0);e.setBackground(glassTintDrawable(INPUT_BG,14));return e;}
    private TextView filledButton(String label,int color){TextView t=text(label,14,true,Color.WHITE);t.setGravity(Gravity.CENTER);t.setBackground(ripple(color,0,16));return t;}
    private TextView outlineButton(String label){TextView t=text(label,14,true,TEXT);t.setGravity(Gravity.CENTER);t.setBackground(glassDrawable(13));return t;}

    private View progressLine(double rate,int color){double safe=Math.max(0,Math.min(1,rate));LinearLayout track=new LinearLayout(this);track.setOrientation(LinearLayout.HORIZONTAL);track.setBackground(rounded(dark?Color.rgb(49,60,72):Color.rgb(234,237,242),0,99));if(safe>0){View fill=new View(this);fill.setBackground(rounded(color,0,99));track.addView(fill,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.MATCH_PARENT,(float)safe));}if(safe<1){View rest=new View(this);track.addView(rest,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.MATCH_PARENT,(float)(1-safe)));}return track;}
    private LinearLayout.LayoutParams progressParams(){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(7));lp.setMargins(0,dp(9),0,0);return lp;}
    private LinearLayout.LayoutParams fieldParams(){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(48));lp.setMargins(0,dp(10),0,0);return lp;}
    private LinearLayout.LayoutParams fieldParamsNoTop(){return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(48));}
    private LinearLayout.LayoutParams cardParams(int top){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);lp.setMargins(0,dp(top),0,0);return lp;}
    private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f);}
    private LinearLayout.LayoutParams weightMargin(int m){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f);lp.setMargins(dp(m),0,dp(m),0);return lp;}

    private int alphaColor(int color,int alpha){return Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color));}
    private GradientDrawable glassDrawable(int radius){
        int top=dark?Color.argb(185,31,42,55):Color.argb(205,255,255,255);
        int bottom=dark?Color.argb(145,20,29,40):Color.argb(150,255,255,255);
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{top,bottom});
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1),dark?Color.argb(50,255,255,255):Color.argb(175,255,255,255));
        return d;
    }
    private GradientDrawable glassTintDrawable(int tint,int radius){
        int a1=dark?175:190,a2=dark?125:145;
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{alphaColor(tint,a1),alphaColor(tint,a2)});
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1),dark?Color.argb(46,255,255,255):Color.argb(160,255,255,255));
        return d;
    }
    private GradientDrawable glassHeroDrawable(int radius){
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(242,28,39,88),Color.argb(232,74,61,168),Color.argb(224,81,76,196)});
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1),Color.argb(90,255,255,255));
        return d;
    }

    private Drawable ripple(int fill,int stroke,int radius){GradientDrawable content=rounded(fill,stroke,radius);GradientDrawable mask=rounded(Color.WHITE,0,radius);return new RippleDrawable(ColorStateList.valueOf(Color.argb(25,0,0,0)),content,mask);}
    private GradientDrawable rounded(int fill,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private GradientDrawable gradientRounded(int start,int end,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{start,end});d.setCornerRadius(dp(radius));return d;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private void selectNav(int i){selectedNav=i;updateNav();}

    private class GlassBackdropView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        GlassBackdropView(){super(MainActivity.this);}
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas);
            canvas.drawColor(BG);
            float w=getWidth(),h=getHeight();
            drawGlow(canvas,w*0.12f,h*0.12f,Math.max(w,h)*0.42f,dark?Color.argb(45,68,116,255):Color.argb(80,116,157,255));
            drawGlow(canvas,w*0.92f,h*0.28f,Math.max(w,h)*0.38f,dark?Color.argb(42,132,80,240):Color.argb(75,196,154,255));
            drawGlow(canvas,w*0.28f,h*0.82f,Math.max(w,h)*0.36f,dark?Color.argb(38,31,187,132):Color.argb(62,94,224,181));
        }
        private void drawGlow(Canvas canvas,float x,float y,float radius,int color){
            paint.setShader(new RadialGradient(x,y,radius,new int[]{color,Color.TRANSPARENT},null,Shader.TileMode.CLAMP));
            canvas.drawCircle(x,y,radius,paint);
            paint.setShader(null);
        }
    }

    private class RingProgressView extends View {
        private final double rate; private final int active,track,textColor; private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        RingProgressView(double rate,int active,int track,int textColor){super(MainActivity.this);this.rate=Math.max(0,rate);this.active=active;this.track=track;this.textColor=textColor;}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float stroke=dp(8),pad=stroke/2f+dp(4);RectF oval=new RectF(pad,pad,getWidth()-pad,getHeight()-pad);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(stroke);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(track);canvas.drawArc(oval,-90,360,false,p);p.setColor(active);canvas.drawArc(oval,-90,(float)(360*Math.min(1,rate)),false,p);p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(dp(13));p.setColor(textColor);canvas.drawText(new DecimalFormat("0%").format(Math.min(1,rate)),getWidth()/2f,getHeight()/2f+dp(5),p);}
    }

    private class LineChartView extends View {
        private final List<Double> values;
        private final int color;
        private final long startMs, endMs;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final SimpleDateFormat axisDateFmt = new SimpleDateFormat("MM/dd", Locale.CHINA);
        private final SimpleDateFormat tooltipDateFmt = new SimpleDateFormat("MM月dd日", Locale.CHINA);
        private final int touchSlop;
        private float revealProgress = 0f;
        private int selectedIndex = -1;
        private float downX, downY;
        private boolean longPressActive = false;
        private boolean pointerDown = false;
        private Runnable longPressRunnable;
        private Runnable clearSelectionRunnable;
        private ValueAnimator revealAnimator;

        LineChartView(List<Double> values, int color, long startMs, long endMs) {
            super(MainActivity.this);
            this.values = values;
            this.color = color;
            this.startMs = startMs;
            this.endMs = endMs;
            this.touchSlop = ViewConfiguration.get(MainActivity.this).getScaledTouchSlop();
            setClickable(true);
            setFocusable(true);
            setContentDescription("每日消费趋势图，长按并左右拖动查看每天消费金额");
        }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (revealAnimator != null) revealAnimator.cancel();
            revealProgress = 0f;
            revealAnimator = ValueAnimator.ofFloat(0f, 1f);
            revealAnimator.setDuration(720);
            revealAnimator.setInterpolator(new DecelerateInterpolator());
            revealAnimator.addUpdateListener(a -> {
                revealProgress = (float) a.getAnimatedValue();
                invalidate();
            });
            revealAnimator.start();
        }

        @Override protected void onDetachedFromWindow() {
            if (revealAnimator != null) revealAnimator.cancel();
            if (longPressRunnable != null) removeCallbacks(longPressRunnable);
            if (clearSelectionRunnable != null) removeCallbacks(clearSelectionRunnable);
            super.onDetachedFromWindow();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float left = dp(50), top = dp(14), right = getWidth() - dp(12), bottom = getHeight() - dp(38);
            if (right <= left || bottom <= top) return;

            double rawMax = 0;
            for (double v : values) rawMax = Math.max(rawMax, v);
            double axisMax = niceAxisMax(rawMax);

            drawAxes(canvas, left, top, right, bottom, axisMax);
            drawDateLabels(canvas, left, right, bottom);

            if (values.isEmpty() || rawMax <= 0) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(MUTED);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTypeface(Typeface.DEFAULT);
                p.setTextSize(dp(12));
                canvas.drawText("暂无消费数据", (left + right) / 2f, (top + bottom) / 2f, p);
                return;
            }

            Path path = buildAnimatedPath(left, top, right, bottom, axisMax);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(3));
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(color);
            canvas.drawPath(path, p);

            int step = Math.max(1, values.size() / 7);
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            for (int i = 0; i < values.size(); i += step) {
                float normalizedX = values.size() <= 1 ? 0f : i / (float) (values.size() - 1);
                if (normalizedX > revealProgress + 0.001f) break;
                float x = xForIndex(i, left, right);
                float y = yForValue(values.get(i), axisMax, top, bottom);
                canvas.drawCircle(x, y, dp(2.5f), p);
            }
            if (!values.isEmpty() && revealProgress >= .999f) {
                int last = values.size() - 1;
                canvas.drawCircle(xForIndex(last, left, right), yForValue(values.get(last), axisMax, top, bottom), dp(2.5f), p);
            }

            if (selectedIndex >= 0 && selectedIndex < values.size()) {
                drawSelection(canvas, left, top, right, bottom, axisMax, selectedIndex);
            }
        }

        private Path buildAnimatedPath(float left, float top, float right, float bottom, double axisMax) {
            Path path = new Path();
            if (values.isEmpty()) return path;
            if (values.size() == 1) {
                float x = left;
                float y = yForValue(values.get(0), axisMax, top, bottom);
                path.moveTo(x, y);
                path.lineTo(x + Math.max(dp(1), (right - left) * revealProgress), y);
                return path;
            }
            float progressIndex = revealProgress * (values.size() - 1);
            int full = Math.min(values.size() - 1, (int) Math.floor(progressIndex));
            float fraction = progressIndex - full;
            for (int i = 0; i <= full; i++) {
                float x = xForIndex(i, left, right);
                float y = yForValue(values.get(i), axisMax, top, bottom);
                if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
            }
            if (full < values.size() - 1 && fraction > 0f) {
                float x1 = xForIndex(full, left, right), y1 = yForValue(values.get(full), axisMax, top, bottom);
                float x2 = xForIndex(full + 1, left, right), y2 = yForValue(values.get(full + 1), axisMax, top, bottom);
                path.lineTo(x1 + (x2 - x1) * fraction, y1 + (y2 - y1) * fraction);
            }
            return path;
        }

        private void drawAxes(Canvas canvas, float left, float top, float right, float bottom, double axisMax) {
            p.setTypeface(Typeface.DEFAULT);
            p.setStrokeWidth(dp(1));
            p.setTextSize(dp(9));
            for (int i = 0; i <= 4; i++) {
                float y = bottom - (bottom - top) * i / 4f;
                p.setColor(LINE);
                canvas.drawLine(left, y, right, y, p);
                double value = axisMax * i / 4d;
                p.setStyle(Paint.Style.FILL);
                p.setColor(MUTED);
                p.setTextAlign(Paint.Align.RIGHT);
                canvas.drawText(axisMoney(value), left - dp(7), y + dp(3), p);
            }
            p.setColor(dark ? Color.rgb(82, 96, 112) : Color.rgb(203, 210, 220));
            p.setStrokeWidth(dp(1));
            canvas.drawLine(left, top, left, bottom, p);
            canvas.drawLine(left, bottom, right, bottom, p);
        }

        private void drawDateLabels(Canvas canvas, float left, float right, float bottom) {
            if (values.isEmpty()) return;
            int labelCount = Math.min(5, values.size());
            p.setStyle(Paint.Style.FILL);
            p.setColor(MUTED);
            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(dp(9));
            for (int j = 0; j < labelCount; j++) {
                int index = labelCount == 1 ? 0 : Math.round(j * (values.size() - 1f) / (labelCount - 1f));
                float x = xForIndex(index, left, right);
                if (j == 0) p.setTextAlign(Paint.Align.LEFT);
                else if (j == labelCount - 1) p.setTextAlign(Paint.Align.RIGHT);
                else p.setTextAlign(Paint.Align.CENTER);
                canvas.drawText(axisDateFmt.format(new Date(dayTimestamp(index))), x, bottom + dp(18), p);
            }
        }

        private void drawSelection(Canvas canvas, float left, float top, float right, float bottom, double axisMax, int index) {
            float x = xForIndex(index, left, right);
            float y = yForValue(values.get(index), axisMax, top, bottom);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1));
            p.setColor(Color.argb(dark ? 150 : 110, 70, 90, 120));
            canvas.drawLine(x, top, x, bottom, p);

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE);
            canvas.drawCircle(x, y, dp(6), p);
            p.setColor(color);
            canvas.drawCircle(x, y, dp(3.5f), p);

            String date = tooltipDateFmt.format(new Date(dayTimestamp(index)));
            String amount = "¥" + money.format(values.get(index));
            String label = date + "   " + amount;
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(dp(11));
            float textW = p.measureText(label);
            float bubbleW = textW + dp(22);
            float bubbleH = dp(34);
            float bx = Math.max(left, Math.min(right - bubbleW, x - bubbleW / 2f));
            float by = Math.max(dp(2), y - bubbleH - dp(12));
            if (by < top - dp(4)) by = Math.min(bottom - bubbleH - dp(8), y + dp(12));
            RectF bubble = new RectF(bx, by, bx + bubbleW, by + bubbleH);
            fillPaint.setColor(dark ? Color.rgb(235, 240, 248) : Color.rgb(26, 36, 52));
            canvas.drawRoundRect(bubble, dp(12), dp(12), fillPaint);
            p.setStyle(Paint.Style.FILL);
            p.setColor(dark ? Color.rgb(25, 35, 48) : Color.WHITE);
            p.setTextAlign(Paint.Align.CENTER);
            canvas.drawText(label, bubble.centerX(), bubble.centerY() + dp(4), p);
            p.setTypeface(Typeface.DEFAULT);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            float left = dp(50), right = getWidth() - dp(12);
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pointerDown = true;
                    longPressActive = false;
                    downX = event.getX();
                    downY = event.getY();
                    if (clearSelectionRunnable != null) removeCallbacks(clearSelectionRunnable);
                    longPressRunnable = () -> {
                        if (!pointerDown) return;
                        longPressActive = true;
                        getParent().requestDisallowInterceptTouchEvent(true);
                        updateSelectedIndex(downX, left, right);
                        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    };
                    postDelayed(longPressRunnable, 260);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!longPressActive) {
                        float dx = event.getX() - downX, dy = event.getY() - downY;
                        if (Math.hypot(dx, dy) > touchSlop) {
                            if (longPressRunnable != null) removeCallbacks(longPressRunnable);
                            if (Math.abs(dx) > Math.abs(dy) * 1.15f) {
                                longPressActive = true;
                                getParent().requestDisallowInterceptTouchEvent(true);
                                updateSelectedIndex(event.getX(), left, right);
                            }
                        }
                    } else updateSelectedIndex(event.getX(), left, right);
                    return true;
                case MotionEvent.ACTION_UP:
                    pointerDown = false;
                    if (longPressRunnable != null) removeCallbacks(longPressRunnable);
                    getParent().requestDisallowInterceptTouchEvent(false);
                    if (!longPressActive && Math.hypot(event.getX() - downX, event.getY() - downY) <= touchSlop * 1.5f) {
                        updateSelectedIndex(event.getX(), left, right);
                        performClick();
                    }
                    longPressActive = false;
                    scheduleSelectionClear();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    pointerDown = false;
                    if (longPressRunnable != null) removeCallbacks(longPressRunnable);
                    getParent().requestDisallowInterceptTouchEvent(false);
                    longPressActive = false;
                    scheduleSelectionClear();
                    return true;
            }
            return super.onTouchEvent(event);
        }

        @Override public boolean performClick() {
            super.performClick();
            return true;
        }

        private void updateSelectedIndex(float x, float left, float right) {
            if (values.isEmpty()) return;
            float clamped = Math.max(left, Math.min(right, x));
            float ratio = right <= left ? 0f : (clamped - left) / (right - left);
            int index = Math.round(ratio * Math.max(0, values.size() - 1));
            index = Math.max(0, Math.min(values.size() - 1, index));
            if (index != selectedIndex) {
                selectedIndex = index;
                invalidate();
            }
        }

        private void scheduleSelectionClear() {
            if (clearSelectionRunnable != null) removeCallbacks(clearSelectionRunnable);
            clearSelectionRunnable = () -> {
                selectedIndex = -1;
                invalidate();
            };
            postDelayed(clearSelectionRunnable, 1800);
        }

        private float xForIndex(int index, float left, float right) {
            return values.size() <= 1 ? left : left + (right - left) * index / (float) (values.size() - 1);
        }

        private float yForValue(double value, double axisMax, float top, float bottom) {
            return bottom - (float) ((Math.max(0, value) / Math.max(1d, axisMax)) * (bottom - top));
        }

        private long dayTimestamp(int index) {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(startMs);
            c.add(Calendar.DAY_OF_MONTH, Math.max(0, index));
            return Math.min(c.getTimeInMillis(), Math.max(startMs, endMs - 1));
        }

        private double niceAxisMax(double max) {
            if (max <= 0) return 100d;
            double rough = max * 1.10d;
            double power = Math.pow(10, Math.floor(Math.log10(rough)));
            double normalized = rough / power;
            double nice;
            if (normalized <= 1d) nice = 1d;
            else if (normalized <= 2d) nice = 2d;
            else if (normalized <= 5d) nice = 5d;
            else nice = 10d;
            return nice * power;
        }

        private String axisMoney(double value) {
            if (value >= 10000) return "¥" + new DecimalFormat("0.#").format(value / 10000d) + "万";
            if (value >= 1000) return "¥" + new DecimalFormat("0.#").format(value / 1000d) + "k";
            return "¥" + new DecimalFormat("0").format(value);
        }
    }

    private class DonutChartView extends View {
        private final List<Double> values; private final double total; private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        DonutChartView(List<Double> values,double total){super(MainActivity.this);this.values=values;this.total=total;}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float stroke=dp(20),pad=stroke/2f+dp(6);RectF oval=new RectF(pad,pad,getWidth()-pad,getHeight()-pad);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(stroke);p.setStrokeCap(Paint.Cap.BUTT);double sum=0;for(double v:values)sum+=v;if(sum<=0){p.setColor(LINE);canvas.drawArc(oval,-90,360,false,p);}else{float start=-90;int[] colors=chartColors();for(int i=0;i<values.size();i++){float sweep=(float)(360*values.get(i)/sum);p.setColor(colors[i%colors.length]);canvas.drawArc(oval,start,sweep,false,p);start+=sweep;}}p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setColor(TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(dp(13));canvas.drawText("¥"+new DecimalFormat("#,##0").format(total),getWidth()/2f,getHeight()/2f,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(dp(9));p.setColor(MUTED);canvas.drawText("本期支出",getWidth()/2f,getHeight()/2f+dp(14),p);}
    }

    private class BarChartView extends View {
        private final List<Double> values; private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        BarChartView(List<Double> values){super(MainActivity.this);this.values=values;}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float left=dp(12),right=getWidth()-dp(8),top=dp(16),bottom=getHeight()-dp(26);p.setStrokeWidth(dp(1));p.setColor(LINE);for(int i=0;i<4;i++){float y=top+(bottom-top)*i/3f;canvas.drawLine(left,y,right,y,p);}double max=0;for(double v:values)max=Math.max(max,v);if(max<=0){p.setTextAlign(Paint.Align.CENTER);p.setTextSize(dp(11));p.setColor(MUTED);canvas.drawText("暂无支出数据",getWidth()/2f,getHeight()/2f,p);return;}float width=(right-left)/Math.max(1,values.size());float barW=Math.max(dp(3),width*.48f);for(int i=0;i<values.size();i++){float x=left+width*i+width/2f;float h=(float)((values.get(i)/max)*(bottom-top));RectF r=new RectF(x-barW/2,bottom-h,x+barW/2,bottom);p.setColor(BLUE);canvas.drawRoundRect(r,barW/2,barW/2,p);}p.setTextSize(dp(9));p.setColor(MUTED);p.setTextAlign(Paint.Align.LEFT);canvas.drawText("开始",left,getHeight()-dp(5),p);p.setTextAlign(Paint.Align.RIGHT);canvas.drawText("现在",right,getHeight()-dp(5),p);}
    }
}
